servicios = {
    'Neumologia pediátrica':'Neumologia pediátrica',
    'Neumologia':'Neumologia',
    'Cardiologia':'Cardiologia',
    'Cardiologia pediátrica':'Cardiologia pediátrica',
    'Gastroenterologia':'Gastroenterologia',
    'Otorrinolaringologia':'Otorrinolaringologia',
    'Medicina interna':'Medicina interna',
    'Diabetologia':'Diabetologia',
    'Medicina Ocupacional':'Medicina Ocupacional',
    'Medicina General':'Medicina General',
    'Medicina de Emergencia':'Medicina de Emergencia',
    'Urologia':'Urologia',
    'Cardiologia intervencionista':'Cardiologia intervencionista',
    'Cardiologia (arritmiologo)':'Cardiologia (arritmiologo)',
    'Cardiologia (hemodinamista)':'Cardiologia (hemodinamista)',
    'Angiologia':'Angiologia',
    'Medicina de Imágenes':'Medicina de Imágenes'
}

metodos_pago = (
    ('Pago móvil', 'Pago móvil'), 
    ('Transferencia', 'Transferencia'), 
    ('Zelle', 'Zelle'), 
    ('Débito', 'Débito'),
    ('Efectivo BS', 'Efectivo BS'),
    ('Efectivo Dólares', 'Efectivo Dólares'), 
    ('Efectivo Euros', 'Efectivo Euros'),
)