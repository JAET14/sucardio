from django.contrib import admin
from apps.anuncios.models import Usuario, Anuncios

# Register your models here.

admin.site.register(Usuario)
admin.site.register(Anuncios)

