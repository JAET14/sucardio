from django.contrib import admin
from apps.citas.models import Cita, Medico

# Register your models here.
admin.site.register(Cita)
admin.site.register(Medico)
