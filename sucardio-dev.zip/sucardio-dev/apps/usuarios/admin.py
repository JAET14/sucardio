from django.contrib import admin
from .models import Notificacion
# Register your models here.
admin.site.register(Notificacion)