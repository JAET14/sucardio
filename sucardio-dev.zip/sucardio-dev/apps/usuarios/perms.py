permissions_user = {
    'AD': [
        'requiere_admin',
        'requiere_secretria',
        'requiere_usuario',
    ],
    'SE': [
        'requiere_usuario',
        'requiere_secretria',
        ],
    'CL': [
        'requiere_usuario',
    ]
}